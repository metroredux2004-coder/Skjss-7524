# Reproduce the molecular experiments

Install Bun, then run `bun run run-experiments.ts` from this folder. No dependencies required. Results are saved under `data/`; use RESULTS_DIR to override. The same physics.ts engine powers the interactive app. Reference results are included in reference-data/.

Units: time/dt ps; temperature K; pressure kPa; speed m/s; impulse N s; wall/pair rates events/ps; energy J.
